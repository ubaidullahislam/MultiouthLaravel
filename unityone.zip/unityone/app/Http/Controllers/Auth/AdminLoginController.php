<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

class AdminLoginController extends Controller
{
    public function __construct(){
        $this->middleware('guest:admin',['except'=>['adminlogout']]);
    }
    public function showLoginForm()
    {
        return view('auth.adminlogin');
    }
    public function login(Request $request)
    {
        //validate form data
        $this->validate($request,[
            'email'=>'required|email',
            'password' => 'required|min:6'
        ]);
        //attempt to log the user in
        if(
        Auth::guard('admin')->attempt([
            'email'=>$request->email,
            'password' => $request->password], $request->remember))
        {
//if success then redirect to their intended location
        return redirect()->intended(route('admin.home'));
        }
        // if unseccess , then redirect to the login form
        return redirect()->back()->withinput($request->only('email','remember'));
       
    }
    public function adminlogout()
    {
        Auth::guard('admin')->logout();

        return redirect('/');
    }
}
